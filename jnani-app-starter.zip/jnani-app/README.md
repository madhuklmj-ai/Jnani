# Jnani — zero-budget starter app

A responsive multilingual news-reader website and installable Android Progressive Web App (PWA).

## Included
- English, Kannada and Hindi interface translations.
- India, Karnataka, World, Business, Technology, Science and Sports categories.
- Google News RSS search feeds accessed through the public RSS2JSON conversion endpoint.
- Search, saved stories (local browser storage), source links and automatic refresh every 30 minutes.
- PWA manifest, service worker and install prompt.
- Responsive mobile and desktop layout.

## Run locally
This is a static site. From this folder run:

```bash
python3 -m http.server 8080
```

Open `http://localhost:8080` in your browser. News feed access needs an internet connection.

## Free deployment: Cloudflare Pages
1. Create a free Cloudflare account.
2. Create a GitHub repository and upload all files/folders from this project.
3. In Cloudflare dashboard, open **Workers & Pages → Create → Pages → Connect to Git**.
4. Select the repository. Use framework preset **None**.
5. Set build command to blank (or no build command) and output directory to `/`.
6. Deploy. Cloudflare provides an HTTPS `*.pages.dev` address.

You can also use another static host that supports HTTPS. A secure HTTPS origin is required for service workers and PWA installation (localhost is allowed for local testing).

## Install on Android
1. Open the deployed HTTPS website in Chrome on Android.
2. Tap the browser menu (⋮) and choose **Install app** or **Add to Home screen**.
3. Confirm. Jnani opens from the Android home screen in its own app-style window.

This is an installable PWA, not yet a Play Store APK/AAB. Publishing to Google Play requires packaging/signing and a developer account; that is not included in a zero-cost hosting setup.

## Important limitations / production checklist
- News is fetched from a public third-party RSS conversion service. Its availability, quotas, feed coverage and terms can change. The app shows a fallback message/sample categories if it fails. The fallback stories are explicitly illustrative, not current news.
- Google News RSS is a feed/search aggregator. Verify important stories against original publisher articles before presenting them as confirmed. The source link on each card opens the original item where provided.
- The interface is translated, but article headlines and descriptions are supplied by the feed and are not guaranteed to be translated into the selected language.
- Saved stories are stored only on the current browser/device. There is no cloud sync, account login, server database, comments, likes or admin dashboard in this starter.
- Do not scrape or republish full article text. Link to publishers and respect their terms, copyright and attribution requirements.
- For a production social network, add a backend (for example Supabase free tier, subject to current quotas), authentication, moderation/reporting, database policies, secure feed proxy, rate limiting, privacy policy and backups. Keep API secrets server-side.
- Daily push notifications require a push service and user opt-in; this starter refreshes when open, not in the background.

## Project structure
```
index.html
styles.css
app.js
manifest.webmanifest
sw.js
icons/icon-192.png
icons/icon-512.png
README.md
```
